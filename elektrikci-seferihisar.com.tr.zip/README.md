## Tech Stack

- Languages: HTML, CSS, JS
- Libraries and frameworks used: PicoCSS Framework
- Fonts used: system-ui
